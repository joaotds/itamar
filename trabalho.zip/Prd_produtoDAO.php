<?php
include "conexao.php";

class Prd_produtoDAO {
    private $con;

    public function __construct() {
        $this->con = Conexao::conectar();
    }

    public function inserir($obj) {
        $sql = "INSERT INTO PRD_PRODUTO (codigo, descricao, id_marca, id_unidade_media, especificacao_tecnica, estoque, peso_liquido, peso_bruto, gtin_ean, gtin_dun, cod_barra) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([
            $obj->getCodigo(),
            $obj->getDescricao(),
            $obj->getId_marca(),
            $obj->getId_unidade_media(),
            $obj->getEspecificacao_tecnica(),
            $obj->getEstoque(),
            $obj->getPeso_liquido(),
            $obj->getPeso_bruto(),
            $obj->getGtin_ean(),
            $obj->getGtin_dun(),
            $obj->getCod_barra()
        ]);
    }
}
?>