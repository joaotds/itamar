<?php
include "conexao.php";

class Prd_preco_vendaDAO {
    private $con;

    public function __construct() {
        $this->con = Conexao::conectar();
    }

    public function inserir($obj) {
        $sql = "INSERT INTO PRD_PRECO_VENDA (id_produto, preco_venda, data_validade_inicial, data_validade_final) VALUES (?, ?, ?, ?)";
        $stmt = $this->con->prepare($sql);
        $stmt->execute([
            $obj->getId_produto(),
            $obj->getPreco_venda(),
            $obj->getData_validade_inicial(),
            $obj->getData_validade_final()
        ]);
    }
}
?>